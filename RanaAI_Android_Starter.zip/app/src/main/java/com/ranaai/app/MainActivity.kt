package com.ranaai.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD")
        }
        setContent { RanaAIApp(
            onSpeak = { text, english ->
                tts?.language = if (english) Locale.US else Locale("bn", "BD")
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rana-ai")
            }
        ) }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RanaAIApp(onSpeak: (String, Boolean) -> Unit) {
    var input by remember { mutableStateOf("") }
    var english by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(ChatMessage(
            "আসসালামু আলাইকুম! আমি Rana AI। কীভাবে সাহায্য করতে পারি?", false
        ))
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun sendMessage() {
        val question = input.trim()
        if (question.isEmpty()) return
        messages.add(ChatMessage(question, true))
        val answer = localReply(question, english)
        messages.add(ChatMessage(answer, false))
        onSpeak(answer, english)
        input = ""
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7C9CFF),
            background = Color(0xFF0B1020),
            surface = Color(0xFF151D32)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF0B1020),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Rana AI", color = Color.White, fontSize = 22.sp)
                            Text(if (english) "Your personal assistant" else "আপনার ব্যক্তিগত সহকারী",
                                color = Color(0xFFB7C5E8), fontSize = 12.sp)
                        }
                    },
                    actions = {
                        TextButton(onClick = { english = !english }) {
                            Text(if (english) "বাংলা" else "English")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF111A2D))
                )
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF111A2D)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text(if (english) "Write a message..." else "কিছু লিখুন...") },
                        shape = RoundedCornerShape(24.dp), singleLine = true
                    )
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (english) "en-US" else "bn-BD")
                        }
                        if (SpeechRecognizer.isRecognitionAvailable(context)) speechLauncher.launch(intent)
                    }) { Icon(Icons.Default.Mic, contentDescription = "Voice input", tint = Color.White) }
                    IconButton(onClick = { sendMessage() }) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF7C9CFF))
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172440))) {
                    Text(
                        if (english) "Ask by typing or using the microphone. Voice replies are enabled."
                        else "লিখে অথবা মাইক্রোফোনে কথা বলে প্রশ্ন করুন। উত্তর পড়ে শোনানোর সুবিধাও আছে।",
                        modifier = Modifier.padding(12.dp), color = Color(0xFFDCE6FF), fontSize = 13.sp
                    )
                }
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { message ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                color = if (message.fromUser) Color(0xFF29477D) else Color(0xFF1A2945),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.widthIn(max = 310.dp)
                            ) {
                                Text(message.text, modifier = Modifier.padding(13.dp), color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

fun localReply(question: String, english: Boolean): String {
    val q = question.lowercase()
    return if (english) {
        when {
            "hello" in q || "hi" in q -> "Hello! I am Rana AI. How can I help you?"
            "time" in q || "date" in q -> "Please check your phone's clock for the current local time and date."
            "who are you" in q -> "I am Rana AI, your personal assistant."
            else -> "I received your message: \"$question\". This starter version works offline with basic replies. Connect a secure AI backend to enable intelligent answers."
        }
    } else {
        when {
            "হ্যালো" in q || "আসসালামু" in q || "সালাম" in q -> "ওয়ালাইকুম আসসালাম! বলুন, কীভাবে সাহায্য করব?"
            "তোমার নাম" in q || "কে তুমি" in q -> "আমি Rana AI, আপনার ব্যক্তিগত সহকারী।"
            "সময়" in q || "তারিখ" in q -> "আপনার ফোনের ঘড়িতে বর্তমান সময় ও তারিখ দেখতে পারবেন।"
            else -> "আপনার কথাটি পেয়েছি: \"$question\"। এটি প্রাথমিক অফলাইন সংস্করণ। বুদ্ধিমান AI উত্তর চালু করতে নিরাপদ AI সার্ভার যুক্ত করতে হবে।"
        }
    }
}
